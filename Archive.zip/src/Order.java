import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {
    private List<Dish> orderedDishes;
    private String deliveryAddress;

    public Order(List<Dish> orderedDishes, String deliveryAddress) {
        this.orderedDishes = orderedDishes;
        this.deliveryAddress = deliveryAddress;
    }

    public List<Dish> getOrderedDishes() {
        return orderedDishes;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Заказ:\n");
        for (Dish dish : orderedDishes) {
            sb.append(dish).append("\n");
        }
        sb.append("Адрес доставки: ").append(deliveryAddress);
        return sb.toString();
    }
}
